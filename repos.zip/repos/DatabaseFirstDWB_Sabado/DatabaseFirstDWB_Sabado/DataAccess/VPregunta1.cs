﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DatabaseFirstDWB_Sabado.DataAccess
{
    public partial class VPregunta1
    {
        public string Idcategoria { get; set; }
        public int Categoria { get; set; }
        public int? Nproductos { get; set; }
    }
}
