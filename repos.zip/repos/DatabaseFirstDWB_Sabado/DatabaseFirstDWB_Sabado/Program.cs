﻿using DatabaseFirstDWB_Sabado.DataAccess;
using System;
using System.Linq;

namespace DatabaseFirstDWB_Sabado
{
    class Program
    {
        public static void Tarea1()
        {
            //select *from Categories
            NorthwindContext dataContext = new NorthwindContext();

            var CategoriesQry = dataContext.Categories.AsQueryable();
            //Materializar Query
            var output = CategoriesQry.ToList(); 
        }
        static void Main(string[] args)
        {
            Tarea1();
            Console.WriteLine("Hello World!");
        }
    }
}
